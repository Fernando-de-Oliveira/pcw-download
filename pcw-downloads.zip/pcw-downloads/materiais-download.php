<link rel="stylesheet" href="www/assets/css/pcw-downloads.css">
<section class="pcw_materiais-downloads">
<aside class="pcw_downloads-left">
    <h1 class="pcw_downloads-title">Materiais para download</h1>
    <p class="pcw_downloads-subtitle">Aqui você encontra recursos de TI como: e-books, whitepapers, webinars, pesquisas, relatórios, vídeos, webcasts e estudos de caso preparados pela indústria de Tecnologia da Informação.</p>

    <div class="pcw_downloads-flex">
        <a href="arquivo.pdf" class="pcw_downloads-box" style="background-color:#40a7f3" download>
            <span class="pcw_downloads-icon pcw_icon-1"></span>
            <span class="pcw_downloads-txt">Os principais fatores para calcular o Custo Total de Propriedade (TCO) de soluções Cloud vs. On-Premise</span>
            <span class="pcw_downloads-fileType">EBOOKS</span>
            <span class="pcw_downloads-fornecedor">IBM</span>
        </a>
        <a href="arquivo.pdf" class="pcw_downloads-box" style="background-color:#54aa9e" download>
            <span class="pcw_downloads-icon pcw_icon-2"></span>
        <span class="pcw_downloads-txt">Os principais fatores para calcular o Custo Total de Propriedade (TCO) de soluções Cloud vs. On-Premise</span>
            <span class="pcw_downloads-fileType">WHITEPAPERS</span>
            <span class="pcw_downloads-fornecedor">NUTANIX</span>
        </a>
        <a href="arquivo.pdf" class="pcw_downloads-box" style="background-color:#3ebcd3" download>
            <span class="pcw_downloads-icon pcw_icon-3"></span>
        <span class="pcw_downloads-txt">Os principais fatores para calcular o Custo Total de Propriedade (TCO) de soluções Cloud vs. On-Premise</span>
            <span class="pcw_downloads-fileType">WEBINARS</span>
            <span class="pcw_downloads-fornecedor">LIFERARY</span>
        </a>
    </div>
</aside>
<div class="pcw_downloads-ad">
    
</div>
</section>
